# 📊 Superstore Sales Dashboard – Data Visualization & Storytelling (Power BI)

## 🎯 Objective
The goal of this project is to master the art of **data storytelling** using Power BI by transforming the **Superstore** dataset into compelling visuals that reveal insights, patterns, and recommendations.

---

## 🗂️ Dataset
**Source:** Sample - Superstore.csv  
- Contains sales, profit, customer, region, and product-level data  
- Timeframe: Multi-year transactional data  
- Size: ~10,000 rows

---

## 🧠 Key Business Questions
- Which products, regions, or segments drive profit?
- Are there areas with high sales but low profitability?
- What trends and seasonal patterns can be observed?
- Where should the business focus to improve performance?

---

## 📋 Dashboard Pages

### 1️⃣ Executive Summary  
- KPIs: Sales, Profit, Orders, Profit Margin  
- Sales trends over time  
- Sales & profit by Region  

### 2️⃣ Product Performance  
- Top Sub-Categories by Sales  
- Profit by Category  
- Tree Map of Product Sales  

### 3️⃣ Regional & Segment Analysis  
- Map of Sales and Profit by State  
- Segment-wise sales by region  

### 4️⃣ Loss Analysis  
- Scatter Plot: Sales vs Profit  
- Table of loss-making products  

### 5️⃣ Insights & Recommendations  
- Summary of key takeaways  
- Strategic recommendations for business action

---

## 🔍 Tools & Features Used
- Power BI Desktop  
- DAX Calculations  
- Tooltips & Slicers  
- Custom Visual Themes  
- Map and Tree Map visuals  
- Exported dashboard to PDF for reporting

---

## 📌 Key Insights
- Texas shows high sales but negative profit — likely due to heavy discounting  
- Technology category leads in profit margins  
- November and December show seasonal sales spikes  
- Office Supplies category underperforms across multiple states  

---

## 🗣️ Interview Preparation (Sample Q&A)
**Q:** What story does your dashboard tell?  
**A:** It highlights how not all high-sales regions are profitable and uncovers where strategic action is needed to improve margins.

**Q:** Why Power BI?  
**A:** Power BI enables fast interactivity, rich visuals, and strong integration with DAX and Excel — ideal for business storytelling.

---

## 📄 Deliverables
- `task 2.pbix` (Power BI Dashboard File)
- `PDF_Report.pdf` (Exported report with insights)
- `README.md` (Project documentation)

---

## ✅ Outcome
Built an interactive, insight-driven dashboard showcasing advanced data visualization and storytelling. Gained hands-on experience in chart selection, data modeling, and business analysis using Power BI.

